import express from 'express'
const app = express();
const PORT = 3000;
app.set("view engine", "ejs");
app.set("views", "./views");


app.get('/', (req, res) => {
    //envio de informação para o EJS
    res.render("index");
})

app.get('/dinossauro/add', (req, res) => {
    res.render("dinossauro/add");
})

app.get('/dinossauro', (req, res) => {
    res.render("dinossauro/lst");
})

app.get('/especie',  (req, res) => {
 res.render("especie/lst");
})

app.get('/especie/add', async (req, res) => {
 
 res.render("especie/add");
})
app.listen(PORT, () => {
    console.log(`servidor rodando em http://localhost:${PORT}`);
});