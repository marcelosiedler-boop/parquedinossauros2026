import mongoose from "mongoose";

const url = "mongodb+srv://aluno:aluno@ifsul.fify4.mongodb.net/?appName=IFSUL"

const conexao = await mongoose.connect(url)

export default conexao

